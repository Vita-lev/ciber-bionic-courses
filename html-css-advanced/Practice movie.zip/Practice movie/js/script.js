window.onload = function() {
    fetch('https://api.themoviedb.org/3/movie/now_playing?api_key=e530dbf87d3f35fe1c14ace5c962084a')
        // .then(function(data) {
        //     return data.json()
        // })
        // .then(function(data) {
        //     console.log(data.results)
        //     let title=
        // })
        .then(function(resp) { return resp.json() })
        .then(function(data) {
            console.log(data.results)
            let a = data.results
            for (let i = 0; i < a.length; i++) {
                document.getElementsByClassName("movie-title")[i].innerHTML = a[i].original_title;
                // document.getElementsByClassName("tempKiev")[i].innerHTML = (Math.round(data.main.temp - 273) + '&deg;');
                document.getElementsByClassName("item-content")[i].textContent = a[i].overview;
                document.getElementsByClassName("blog-item-img")[i].style.backgroundImage = "https://image.tmdb.org/t/p/w500/" + a[i].poster_path;
                //http://openweathermap.org/img/wn/01d@2x.png 
            }
        })
        .catch(function() {
            //catch any errors
        })
}